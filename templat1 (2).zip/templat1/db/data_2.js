var data_2 = 
[
  {
    "insurance_coverage": "기본계약(암진단비)",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "일반상해사망",
    "my_price": 70000000,
    "standard_price": 100000000
  },
  {
    "insurance_coverage": "암(소액암제외)진단비",
    "my_price": 10000000,
    "standard_price": 20000000
  }
]