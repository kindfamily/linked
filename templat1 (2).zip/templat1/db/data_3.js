var data_3 = 
[
  {
    "insurance_coverage": "만기지급금",
    "my_price": 500000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "충전치료보험금 - 금, 도재(세라믹)",
    "my_price": 100000,
    "standard_price": 150000
  },
  {
    "insurance_coverage": "충전치료보험금 - 아말감",
    "my_price": 10000,
    "standard_price": 50000
  },
  {
    "insurance_coverage": "충전치료보험금 - 금, 도재(세라믹), 아말감 이외",
    "my_price": 50000,
    "standard_price": 50000
  },
  {
    "insurance_coverage": "크라운치료보험금",
    "my_price": 200000,
    "standard_price": 300000
  },
  {
    "insurance_coverage": "철성의치(틀니)(Denture)치료보험금",
    "my_price": 500000,
    "standard_price": 700000
  },
  {
    "insurance_coverage": "고정성가공의치(브릿지)(Bridge)치료보험금",
    "my_price": 250000,
    "standard_price": 500000
  },
  {
    "insurance_coverage": "임플란트(Implant)치료보험금",
    "my_price": 500000,
    "standard_price": 650000
  },
  {
    "insurance_coverage": "치과통원급여금",
    "my_price": 5000,
    "standard_price": 15000
  },
  {
    "insurance_coverage": "가철성의치(틀니)(Denture)치료보험금",
    "my_price": 500000,
    "standard_price": 700000
  },
  {
    "insurance_coverage": "고정성가공의치(브릿지)(Bridge)치료보험금",
    "my_price": 250000,
    "standard_price": 300000
  },
  {
    "insurance_coverage": "임플란트(Implant)치료보험금",
    "my_price": 500000,
    "standard_price": 750000
  }
]