var data_1 = 
[
  {
    "insurance_coverage": "일반상해후유장해(3%~100%)(기본계 약)",
    "my_price": 180000000,
    "standard_price": 200000000
  },
  {
    "insurance_coverage": "일반상해80%이상후유장해",
    "my_price": 10000000,
    "standard_price": 20000000
  },
  {
    "insurance_coverage": "일반상해사망",
    "my_price": 180000000,
    "standard_price": 200000000
  },
  {
    "insurance_coverage": "질병80%이상후유장해",
    "my_price": 10000000,
    "standard_price": 20000000
  },
  {
    "insurance_coverage": "강력범죄피해보장",
    "my_price": 3000000,
    "standard_price": 3000000
  },
  {
    "insurance_coverage": "질병특정고도장해진단비",
    "my_price": 10000000,
    "standard_price": 200000000
  },
  {
    "insurance_coverage": "골절진단비Ⅱ",
    "my_price": 300000,
    "standard_price": 500000
  },
  {
    "insurance_coverage": "5대골절진단비",
    "my_price": 200000,
    "standard_price": 400000
  },
  {
    "insurance_coverage": "깁스치료비",
    "my_price": 200000,
    "standard_price": 400000
  },
  {
    "insurance_coverage": "화상진단비",
    "my_price": 300000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "상해수술비",
    "my_price": 500000,
    "standard_price": 800000
  },
  {
    "insurance_coverage": "중대한특정상해수술비",
    "my_price": 3000000,
    "standard_price": 6000000
  },
  {
    "insurance_coverage": "중대한화상및부식진단비",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "상해흉터복원수술비",
    "my_price": 70000,
    "standard_price": 100000
  },
  {
    "insurance_coverage": "(선택형:90%)상해입원형실손의료비 (갱신형)",
    "my_price": 50000000,
    "standard_price": 50000000
  },
  {
    "insurance_coverage": "(선택형)상해통원형(외래)실손의료 비(갱신형)",
    "my_price": 250000,
    "standard_price": 250000
  },
  {
    "insurance_coverage": "(선택형)상해통원형(약제)실손의료 비(갱신형)",
    "my_price": 50000,
    "standard_price": 50000
  },
  {
    "insurance_coverage": "(선택형:90%)질병입원형실손의료비 (갱신형)",
    "my_price": 50000000,
    "standard_price": 50000000
  },
  {
    "insurance_coverage": "(선택형)질병통원형(외래)실손의료 비(갱신형)",
    "my_price": 250000,
    "standard_price": 250000
  },
  {
    "insurance_coverage": "(선택형)질병통원형(약제)실손의료 비(갱신형)",
    "my_price": 50000,
    "standard_price": 50000
  },
  {
    "insurance_coverage": "암진단비(유사암제외)",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "유사암진단비",
    "my_price": 3000000,
    "standard_price": 6000000
  },
  {
    "insurance_coverage": "뇌졸중진단비",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "급성심근경색증진단비",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "항암방사선약물치료비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "암수술비Ⅰ",
    "my_price": 2000000,
    "standard_price": 4000000
  },
  {
    "insurance_coverage": "암수술비II",
    "my_price": 2000000,
    "standard_price": 4000000
  },
  {
    "insurance_coverage": "암직접치료입원일당(4일이상)",
    "my_price": 100000,
    "standard_price": 200000
  },
  {
    "insurance_coverage": "질병수술비",
    "my_price": 200000,
    "standard_price": 400000
  },
  {
    "insurance_coverage": "충수염(맹장염)수술비",
    "my_price": 300000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "피부질환수술비",
    "my_price": 100000,
    "standard_price": 200000
  },
  {
    "insurance_coverage": "호흡기관련질병수술비",
    "my_price": 300000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "유방절제수술비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "자궁적출수술비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "간질환수술비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "21대질병수술비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "특정전염병진단보장",
    "my_price": 300000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "말기폐질환진단비",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "말기간경화진단비",
    "my_price": 20000000,
    "standard_price": 40000000
  },
  {
    "insurance_coverage": "말기신부전증진단비",
    "my_price": 10000000,
    "standard_price": 20000000
  },
  {
    "insurance_coverage": "결핵진단비",
    "my_price": 300000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "만성당뇨합병증진단비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "크론병진단비",
    "my_price": 10000000,
    "standard_price": 10000000
  },
  {
    "insurance_coverage": "다발경화증진단비",
    "my_price": 10000000,
    "standard_price": 10000000
  },
  {
    "insurance_coverage": "중대한재생불량성빈혈진단비",
    "my_price": 10000000,
    "standard_price": 10000000
  },
  {
    "insurance_coverage": "5대장기이식수술비",
    "my_price": 20000000,
    "standard_price": 20000000
  },
  {
    "insurance_coverage": "조혈모세포이식수술비",
    "my_price": 20000000,
    "standard_price": 20000000
  },
  {
    "insurance_coverage": "각막이식수술비",
    "my_price": 20000000,
    "standard_price": 20000000
  },
  {
    "insurance_coverage": "인공관절수술비",
    "my_price": 1000000,
    "standard_price": 2000000
  },
  {
    "insurance_coverage": "추간판장애수술비",
    "my_price": 300000,
    "standard_price": 600000
  },
  {
    "insurance_coverage": "가족일상생활중배상책임Ⅱ",
    "my_price": 100000000,
    "standard_price": 200000000
  }
];